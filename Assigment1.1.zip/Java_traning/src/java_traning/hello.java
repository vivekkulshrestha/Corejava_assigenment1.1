package java_traning;

public class hello {

	public static void main(String[] args) 
	{
		// Printing the Hello World in Output
		System.out.println("Hello World");

	}

}
